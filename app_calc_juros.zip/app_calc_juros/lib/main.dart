import 'package:flutter/material.dart';

import 'calculadora_juros.dart';

/// Aplicativo de exemplo: Calculadora de Juros Compostos
void main() => runApp(const CalculadoraJurosApp());