import 'package:flutter/material.dart';

class CalculadoraJurosApp extends StatelessWidget {
  const CalculadoraJurosApp({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      home: const CalculadoraJurosPage(),
    );
  }
}

class CalculadoraJurosPage extends StatefulWidget {
  const CalculadoraJurosPage({Key? key}) : super(key: key);

  @override
  State createState() => _CalculadoraJurosPageState();
}

class _CalculadoraJurosPageState extends State {
  final TextEditingController _capitalController1 = TextEditingController();
  final TextEditingController _aplicacaoMensalController1 = TextEditingController();
  final TextEditingController _mesesController1 = TextEditingController();
  final TextEditingController _taxaJurosController1 = TextEditingController();
  
  final TextEditingController _capitalController2 = TextEditingController();
  final TextEditingController _aplicacaoMensalController2 = TextEditingController();
  final TextEditingController _mesesController2 = TextEditingController();
  final TextEditingController _taxaJurosController2 = TextEditingController();

  void _mostrarAlerta(String mensagem) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Atenção'),
        content: Text(mensagem),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(context).pop(),
            child: const Text('OK'),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Comparador de Investimentos', style: TextStyle(color: Colors.white)),
         backgroundColor: Colors.lightGreen.shade800,
        ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          children: [
            const Text(
              'Primeiro Investimento:',
              style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
            ),
            _label(controller: _capitalController1, label: 'Investimento inicial (R\$)'),
            _label(controller: _aplicacaoMensalController1, label: 'Aplicação mensal (R\$)'),
            _label(controller: _mesesController1, label: 'Período (meses)', tipoTeclado: TextInputType.number),
            _label(controller: _taxaJurosController1, label: 'Taxa de juros mensal (%)'),

            const SizedBox(height: 20),
            const Text(
              'Segundo Investimento:',
              style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
            ),
            _label(controller: _capitalController2, label: 'Investimento inicial (R\$)'),
            _label(controller: _aplicacaoMensalController2, label: 'Aplicação mensal (R\$)'),
            _label(controller: _mesesController2, label: 'Período (meses)', tipoTeclado: TextInputType.number),
            _label(controller: _taxaJurosController2, label: 'Taxa de juros mensal (%)'),

            Padding(
              padding: const EdgeInsets.symmetric(vertical: 16.0),
              child: ElevatedButton(
                onPressed: _calcularComparacao,
                child: const Text('Comparar Investimentos'),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _label({
    required TextEditingController controller,
    required String label,
    TextInputType tipoTeclado = TextInputType.number,
  }) {
    return Expanded(
      child: Padding(
        padding: const EdgeInsets.symmetric(vertical: 8.0),
        child: TextFormField(
          controller: controller,
          keyboardType: tipoTeclado,
          decoration: InputDecoration(
            labelText: label,
            border: const OutlineInputBorder(),
          ),
        ),
      ),
    );
  }

  void _calcularComparacao() {
    if (_capitalController1.text.isEmpty || _aplicacaoMensalController1.text.isEmpty ||
        _mesesController1.text.isEmpty || _taxaJurosController1.text.isEmpty ||
        _capitalController2.text.isEmpty || _aplicacaoMensalController2.text.isEmpty ||
        _mesesController2.text.isEmpty || _taxaJurosController2.text.isEmpty) {
      _mostrarAlerta('Por favor, preencha todos os campos!');
      return;
    }

    double capital1 = double.parse(_capitalController1.text);
    double aplicacaoMensal1 = double.parse(_aplicacaoMensalController1.text);
    int meses1 = int.parse(_mesesController1.text);
    double taxaJuros1 = double.parse(_taxaJurosController1.text) / 100;

    double capital2 = double.parse(_capitalController2.text);
    double aplicacaoMensal2 = double.parse(_aplicacaoMensalController2.text);
    int meses2 = int.parse(_mesesController2.text);
    double taxaJuros2 = double.parse(_taxaJurosController2.text) / 100;

    double montanteFinal1 = 0.0;
    List detalhesMeses1 = [];
    for (int i = 1; i <= meses1; i++) {
      double rendimentoMensal = capital1 * taxaJuros1;
      capital1 += rendimentoMensal + aplicacaoMensal1;
      detalhesMeses1.add("Mês $i: Montante = R\$ ${capital1.toStringAsFixed(2)} (Rendimento = R\$ ${rendimentoMensal.toStringAsFixed(2)})");
    }
    montanteFinal1 = capital1;

    double montanteFinal2 = 0.0;
    List detalhesMeses2 = [];
    for (int i = 1; i <= meses2; i++) {
      double rendimentoMensal = capital2 * taxaJuros2;
      capital2 += rendimentoMensal + aplicacaoMensal2;
      detalhesMeses2.add("Mês $i: Montante = R\$ ${capital2.toStringAsFixed(2)} (Rendimento = R\$ ${rendimentoMensal.toStringAsFixed(2)})");
    }
    montanteFinal2 = capital2;

    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) => ResultadosPage(
          montanteFinal1: montanteFinal1,
          montanteFinal2: montanteFinal2,
          detalhesMeses1: detalhesMeses1,
          detalhesMeses2: detalhesMeses2,
        ),
      ),
    );
  }
}

class ResultadosPage extends StatelessWidget {
  final double montanteFinal1;
  final double montanteFinal2;
  final List detalhesMeses1;
  final List detalhesMeses2;

  const ResultadosPage({
    Key? key,
    required this.montanteFinal1,
    required this.montanteFinal2,
    required this.detalhesMeses1,
    required this.detalhesMeses2,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Seus Investimentos', style: TextStyle(color: Colors.white)),
        backgroundColor: Colors.lightGreen.shade800,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back),
          color: Colors.white,
          onPressed: () => Navigator.pop(context),
        ),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              'Investimento 1: Montante final = R\$ ${montanteFinal1.toStringAsFixed(2)}',
              style: const TextStyle(
                fontSize: 20,
                fontWeight: FontWeight.bold,
                color: Colors.green,
              ),
            ),
            const SizedBox(height: 16),
            const Text(
              'Detalhes por mês do Investimento 1:',
              style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
            ),
            Expanded(
              child: ListView.builder(
                itemCount: detalhesMeses1.length,
                itemBuilder: (context, index) {
                  return ListTile(
                    title: Text(detalhesMeses1[index]),
                  );
                },
              ),
            ),
            const SizedBox(height: 16),
            Text(
              'Investimento 2: Montante final = R\$ ${montanteFinal2.toStringAsFixed(2)}',
              style: const TextStyle(
                fontSize: 20,
                fontWeight: FontWeight.bold,
                color: Colors.green,
              ),
            ),
            const SizedBox(height: 16),
            const Text(
              'Detalhes por mês do Investimento 2:',
              style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
            ),
            Expanded(
              child: ListView.builder(
                itemCount: detalhesMeses2.length,
                itemBuilder: (context, index) {
                  return ListTile(
                    title: Text(detalhesMeses2[index]),
                  );
                },
              ),
            ),
          ],
        ),
      ),
    );
  }
}
