package com.example.app_calc_juros

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
